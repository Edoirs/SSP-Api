﻿using System;
using System.Collections.Generic;

namespace InvoiceGenerator.Models;

public partial class InvoiceDetail
{
    public int Id { get; set; }

    public string? InvoiceDate { get; set; }

    public string? PaymentTerms { get; set; }

    public string? Email { get; set; }

    public string? DueDate { get; set; }

    public string? Ponumber { get; set; }

    public string? Note { get; set; }

    public string? NetAmount { get; set; }

    public string? TotalAmount { get; set; }

    public string? TotalDiscount { get; set; }

    public string? TotalShipping { get; set; }

    public string? TotalAmountPaid { get; set; }

    public string? InvoiceFrom { get; set; }

    public string? InvoiceTo { get; set; }

    public string? BillTo { get; set; }

    public string? PdfString { get; set; }
    public string item1 { get; set; }
    public string item2 { get; set; }
    public string item3 { get; set; }
    public string item4 { get; set; }
    public string item5 { get; set; }
    public  int qty1 { get; set; }
    public  int qty2 { get; set; }
    public  int qty3 { get; set; }
    public  int qty4 { get; set; }
    public  int qty5 { get; set; }
    public  int rate1 { get; set; }
    public  int rate2 { get; set; }
    public  int rate3 { get; set; }
    public  int rate4 { get; set; }
    public  int rate5 { get; set; }

    public string ItemJson { get; set; }
    public DateTime CreatedDate { get; set; }
}
