﻿
using HtmlAgilityPack;
using InvoiceGenerator.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Reflection;
using System.Text;
using System.Text.Encodings.Web;
using System.Xml;

namespace InvoiceGenerator.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly InvoiceContext _con;
        public InvoiceController(InvoiceContext con)
        {
            _con = con;
        }

        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult MakePayment([FromBody] InvoiceData obj)
        {
            var detobjII = new InvoiceDataForJson();
            detobjII.item1 = obj.itm1;
            detobjII.item2 = obj.itm2;
            detobjII.item3 = obj.itm3;
            detobjII.item4 = obj.itm4;
            detobjII.item5 = obj.itm5;
            detobjII.qty1 = obj.qty1;
            detobjII.qty2 = obj.qty2;
            detobjII.qty3 = obj.qty3;
            detobjII.qty4 = obj.qty4;
            detobjII.qty5 = obj.qty5;
            detobjII.rate1 = obj.rate1;
            detobjII.rate2 = obj.rate2;
            detobjII.rate3 = obj.rate3;
            detobjII.rate4 = obj.rate4;
            detobjII.rate5 = obj.rate5;
            var st = JsonConvert.SerializeObject(detobjII);
            var detobj = new InvoiceDetail();
            detobj.item1 = obj.itm1;
            detobj.item2 = obj.itm2;
            detobj.item3 = obj.itm3;
            detobj.item4 = obj.itm4;
            detobj.item5 = obj.itm5;
            detobj.qty1 = obj.qty1;
            detobj.qty2 = obj.qty2;
            detobj.qty3 = obj.qty3;
            detobj.qty4 = obj.qty4;
            detobj.qty5 = obj.qty5;
            detobj.rate1 = obj.rate1;
            detobj.rate2 = obj.rate2;
            detobj.rate3 = obj.rate3;
            detobj.rate4 = obj.rate4;
            detobj.rate5 = obj.rate5;
            detobj.InvoiceDate = obj.InvoiceDate;
            detobj.PaymentTerms = obj.PaymentTerms;
            detobj.Email = obj.Email;
            detobj.DueDate = obj.DueDate;
            detobj.Ponumber = obj.PONumber;
            detobj.Note = obj.Note;
            detobj.NetAmount = obj.NetAmount;
            detobj.TotalAmount = obj.TotalAmount;
            detobj.TotalDiscount = obj.TotalDiscount;
            detobj.TotalShipping = obj.TotalShipping;
            detobj.TotalAmountPaid = obj.TotalAmountPaid;
            detobj.InvoiceFrom = obj.InvoiceFrom;
            detobj.InvoiceTo = obj.InvoiceTo;
            detobj.BillTo = obj.BillTo;
            detobj.CreatedDate = DateTime.Now;
            detobj.ItemJson = st;
            _con.InvoiceDetails.Add(detobj);
            _con.SaveChanges();

            return RedirectToAction("PaymentLink");
        }
        public ActionResult PaymentLink()
        {
            return View();
        }
        //[HttpPost]
        //public FileResult ExportII(string ExportData)
        //{
        //    HtmlNode.ElementsFlags["img"] = HtmlElementFlag.Closed;
        //    HtmlNode.ElementsFlags["input"] = HtmlElementFlag.Closed;
        //    HtmlDocument doc = new HtmlDocument();
        //    doc.OptionFixNestedTags = true;
        //    doc.LoadHtml(ExportData);
        //    ExportData = doc.DocumentNode.OuterHtml;

        //    using (MemoryStream stream = new System.IO.MemoryStream())
        //    {
        //        Encoding unicode = Encoding.UTF8;
        //        StringReader sr = new StringReader(ExportData);
        //        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        //        PdfWriter writer = PdfWriter.GetInstance(pdfDoc, stream);
        //        pdfDoc.Open();
        //        XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
        //        pdfDoc.Close();
        //        return File(stream.ToArray(), "application/pdf", "OrderStatus.pdf");
        //    }

        //} 
        //[HttpPost]
        //public FileResult Export([FromBody] ExportPdf exD)
        //{
        //    HtmlNode.ElementsFlags["img"] = HtmlElementFlag.Closed;
        //    HtmlNode.ElementsFlags["input"] = HtmlElementFlag.Closed;
        //    HtmlDocument doc = new HtmlDocument();
        //    doc.OptionFixNestedTags = true;
        //    doc.LoadHtml(exD.ExportData);
        //    exD.ExportData = doc.DocumentNode.OuterHtml;

        //    using (MemoryStream stream = new System.IO.MemoryStream())
        //    {
        //        Encoding unicode = Encoding.UTF8;
        //        StringReader sr = new StringReader(exD.ExportData);
        //        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        //        PdfWriter writer = PdfWriter.GetInstance(pdfDoc, stream);
        //        pdfDoc.Open();
        //        XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
        //        pdfDoc.Close();

        //        var fullPath = exD.InvoiceFrom+".pdf";

        //        byte[] bytes = stream.ToArray();
        //        WriteFile(fullPath,bytes);
        //       // stream.ToArray().CopyTo(fullPath,);
        //        //if (File.Exists(fullPath))
        //        //{
        //        //    File.Delete(fullPath);
        //        //    deleteSuccess = true;
        //        //}
        //        return File(stream.ToArray(), "application/pdf", "OrderStatus.pdf");
        //    }

        //}
        //public void WriteFile(string fileName, byte[] bytes)
        //{
        //    string path = "TemporaryPdf";
        //    //if (!path.EndsWith(@"\")) path += @"\";

        //    //if (File.Exists(Path.Combine(path, fileName)))
        //    //    File.Delete(Path.Combine(path, fileName));
        //    if (Directory.Exists(Path.Combine(path, fileName)))
        //        Directory.Delete(Path.Combine(path, fileName));
        //    using (FileStream fs = new FileStream(Path.Combine(path, fileName), FileMode.CreateNew, FileAccess.Write))
        //    {
        //        fs.Write(bytes, 0, (int)bytes.Length);
        //        //fs.Close();
        //    }
        //}
    }
}
