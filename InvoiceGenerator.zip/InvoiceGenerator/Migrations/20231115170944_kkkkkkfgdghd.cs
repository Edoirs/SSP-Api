﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace InvoiceGenerator.Migrations
{
    /// <inheritdoc />
    public partial class kkkkkkfgdghd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "InvoiceDetail",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InvoiceDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PaymentTerms = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DueDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PONumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Note = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NetAmount = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalAmount = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalDiscount = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalShipping = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalAmountPaid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvoiceFrom = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvoiceTo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BillTo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PdfString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    item1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    item2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    item3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    item4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    item5 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    qty1 = table.Column<int>(type: "int", nullable: false),
                    qty2 = table.Column<int>(type: "int", nullable: false),
                    qty3 = table.Column<int>(type: "int", nullable: false),
                    qty4 = table.Column<int>(type: "int", nullable: false),
                    qty5 = table.Column<int>(type: "int", nullable: false),
                    rate1 = table.Column<int>(type: "int", nullable: false),
                    rate2 = table.Column<int>(type: "int", nullable: false),
                    rate3 = table.Column<int>(type: "int", nullable: false),
                    rate4 = table.Column<int>(type: "int", nullable: false),
                    rate5 = table.Column<int>(type: "int", nullable: false),
                    ItemJson = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InvoiceDetail", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "InvoiceDetail");
        }
    }
}
