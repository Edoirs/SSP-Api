using InvoiceGenerator;
using InvoiceGenerator.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

string? conn = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<InvoiceContext>(opt => opt.UseSqlServer(conn));
var app = builder.Build();



// Configure the HTTP request pipeline.


app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Invoice}/{action=Index}/{id?}");

app.Run();
