function C() {
    /*For Print*/
    window.print();
}

function PrintPdf() {
    const element = document.getElementById('PrintPDF');
    var ret = html2pdf().from(element).save();
    console.log(ret);
    // console.log("i reach here");
    //// $("input[name='ExportData']").val($("#PrintPDF").html());
    // var data = {
    //     ExportData: $("#PrintPDF").html(),
    //     InvoiceFrom: $('#InvoiceFrom').val()
    // };
    // console.log(data);
    // $.ajax({
    //     type: 'POST',
    //     url: '/Invoice/Export', // Replace with the actual URL of your controller action
    //     contentType: 'application/json; charset=utf-8',
    //     data: JSON.stringify(data),
    //     success: function (response) {
    //         $('#result').html(response.message);
    //     },
    //     error: function () {
    //         $('#result').html('An error occurred.');
    //     }
    // });
};
function GetPdf() {

    var data = {
        InvoiceDate: $('#InvoiceDate').val(),
        PaymentTerms: $('#PaymentTerms').val(),
        DueDate: $('#DueDate').val(),
        Note: $('#Note').val(),
        NetAmount: $('#FNet').val(),
        TotalAmount: $('#FTotal').val(),
        TotalDiscount: $('#FGSDiscount').val(),
        TotalShipping: $('#FGSShipping').val(),
        TotalAmountPaid: $('#FGSAmountPaid').val(),
        InvoiceFrom: $('#InvoiceFrom').val(),
        InvoiceTo: $('#InvoiceTo').val(),
        BillTo: $('#BillTo').val(),
        PONumber: $('#PONumber').val()
    };
    console.log(data);
    $.ajax({
        type: 'POST',
        url: '/Invoice/ExportToPDF', // Replace with the actual URL of your controller action
        contentType: 'application/json; charset=utf-8',
        data: JSON.stringify(data),
        success: function (response) {
            $('#result').html(response.message);
        },
        error: function () {
            $('#result').html('An error occurred.');
        }
    });
}

function BtnAdd() {
    /*Add Button*/
    var v = $("#TRow").clone().appendTo("#TBody");
    $(v).find("input").val('');
    $(v).removeClass("d-none");
    $(v).find("th").first().html($('#TBody tr').length - 1);
}

function BtnDel(v) {
    /*Delete Button*/
    $(v).parent().parent().remove();
    GetTotal();

    let button = document.getElementById("addBtn");
    $("#TBody").find("tr").each(
        function (index) {
            $(this).find("th").first().html(index);
        }

    );
    var rowCount = $("#Table_id tr").length;
    if (rowCount != 7) {
        button.disabled = false;
    }
}
function BtnSubmit(v) {
    debugger
    var qty1 = 0; var qty2 = 0; var qty3 = 0; var qty4 = 0; var qty5 = 0;
    var itm1 = ""; var itm2 = ""; var itm3 = ""; var itm4 = ""; var itm5 = "";
    var rate1 = 0; var rate2 = 0; var rate3 = 0; var rate4 = 0; var rate5 = 0;
    var rowCount = $("#Table_id tr").length;
    var rowCountII = document.getElementsByName("qty").length;
    for (let i = 2; i <= rowCountII; i++) {
        var itm = document.getElementsByName("itm")[i - 1].value;
        var qty = document.getElementsByName("qty")[i - 1].value;
        var rate = document.getElementsByName("rate")[i - 1].value;
        switch (i) {
            case 2:
                qty1 = qty;
                itm1 = itm;
                rate1 = rate;
                break;
            case 3:
                qty2 = qty;
                itm2 = itm;
                rate2 = rate;
                break;
            case 6:
                qty3 = qty;
                itm3 = itm;
                rate3 = rate;
                break;
            case 7:
                qty4 = qty;
                itm4 = itm;
                rate4 = rate;
                break;
            case 8:
                qty5 = qty;
                itm5 = itm;
                rate5 = rate;
                break;
            default:
                break;
        }
    }
    var data = {
        InvoiceDate: $('#InvoiceDate').val(),
        PaymentTerms: $('#PaymentTerms').val(),
        DueDate: $('#DueDate').val(),
        Note: $('#Note').val(),
        Email: $('#email').val(),
        NetAmount: $('#FNet').val(),
        TotalAmount: $('#FTotal').val(),
        TotalDiscount: $('#FGSDiscount').val(),
        TotalShipping: $('#FGSShipping').val(),
        TotalAmountPaid: $('#FGSAmountPaid').val(),
        InvoiceFrom: $('#InvoiceFrom').val(),
        InvoiceTo: $('#InvoiceTo').val(),
        BillTo: $('#BillTo').val(),
        qty1: qty1,
        qty2: qty2,
        qty3: qty3,
        qty4: qty4,
        qty5: qty5,
        itm1: itm1,
        itm2: itm2,
        itm3: itm3,
        itm4: itm4,
        itm5: itm5,
        rate1: rate1,
        rate2: rate2,
        rate3: rate3,
        rate4: rate4,
        rate5: rate5,
        PONumber: $('#PONumber').val()
    };
    console.log(data);
    $.ajax({
        type: 'POST',
        url: '/Invoice/MakePayment', // Replace with the actual URL of your controller action
        contentType: 'application/json; charset=utf-8',
        data: JSON.stringify(data),
        success: function (response) {
            $('#result').html(response.message);
        },
        error: function () {
            $('#result').html('An error occurred.');
        }
    });
};
function Calc(v) {
    /*Detail Calculation Each Row*/
    var index = $(v).parent().parent().index();

    var qty = document.getElementsByName("qty")[index].value;
    var rate = document.getElementsByName("rate")[index].value;
    var amt = qty * rate;
    document.getElementsByName("amt")[index].value = amt;

    GetTotal();
}


function GetTotal() {
    /*Footer Calculation*/

    var sum = 0;
    var sumWithTax = 0;
    var sumWithDiscount = 0;
    var amts = document.getElementsByName("amt");

    for (let index = 0; index < amts.length; index++) {
        var amt = amts[index].value;
        sum = +(sum) + +(amt);
    }


    var gst = document.getElementById("FGST").value;
    var discount = document.getElementById("FGSDiscount").value;
    if (gst > 0) {
        sumWithTax = sum / gst;
        sumWithTax = Math.round((sumWithTax + Number.EPSILON) * 100) / 100;
    } else {
        sumWithTax = 0;
    }
    if (discount > 0) {
        sumWithDiscount = sum / discount;
        sumWithDiscount = Math.round((sumWithDiscount + Number.EPSILON) * 100) / 100;
    } else {
        sumWithDiscount = 0;
    }
    sum = +(sum) + +(sumWithTax) - (sumWithDiscount);
    document.getElementById("FTotal").value = sum
    var gsShipping = document.getElementById("FGSShipping").value;
    var gsAmountPaid = document.getElementById("FGSAmountPaid").value;
    var net = +(sum) + +(gsShipping) - (gsAmountPaid);
    document.getElementById("FNet").value = net;

}